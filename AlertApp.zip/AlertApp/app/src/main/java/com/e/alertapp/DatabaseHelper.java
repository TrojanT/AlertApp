package com.e.alertapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

	public static final String DB_NAME="AlertAppDB";
	public static final String DB_TABLE="Task";
	public static final String DB_COLUMN = "TaskName";
	public static final String DB_COLUMN2 = "Time";
	public static final String DB_COLUMN3 = "Date";

	public DatabaseHelper(Context context){super(context,DB_NAME,null,1);}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String createTable = "CREATE TABLE "+ DB_TABLE +" (ID INTEGER PRIMARY KEY AUTOINCREMENT, TaskName TEXT, Time TEXT, Date TEXT)";
		db.execSQL(createTable);


	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP IF TABLE EXISTS "+ DB_TABLE);

	}

	public boolean addData(String task, String task2, String task3){

		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put(DB_COLUMN,task);
		contentValues.put(DB_COLUMN2,task2);
		contentValues.put(DB_COLUMN3,task3);

		long result = db.insert(DB_TABLE,null,contentValues);
		if(result == -1){
			return false;
		}else {
			return true;
		}

	}


	public ArrayList<Details> getAllData(){
		ArrayList<Details> arrayList = new ArrayList<>();
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db .rawQuery("SELECT * FROM "+DB_TABLE,null);

		while (cursor.moveToNext()){
			int id = cursor.getInt(0);
			String name = cursor.getString(1);
			String age = cursor.getString(2);
			String date = cursor.getString(3);
			Details details = new Details(id,name,age,date);

			arrayList.add(details);
		}
		return arrayList;
	}

	public void deleteTask(String task){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(DB_TABLE,DB_COLUMN + " = ?",new String[]{task});
        db.close();
    }

}
