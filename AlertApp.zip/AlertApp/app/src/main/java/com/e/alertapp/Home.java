package com.e.alertapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Home extends AppCompatActivity {

	ListView lstTask;
	DatabaseHelper myDB;
	ArrayList<Details> arrayList;
	MyAdapter myAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home2);
		FloatingActionButton fab = findViewById(R.id.fabBtn);
		lstTask = findViewById(R.id.listV);
		myDB = new DatabaseHelper(this);
		arrayList=new ArrayList<>();


		fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent intent =new Intent(Home.this,MainActivity.class );
				startActivity(intent);
			}
		});
		loadDataInListView();


	}


	public void deleteTask(View view){
		View parent = (View)view.getParent();
		TextView taskTextView = (TextView)parent.findViewById(R.id.task_title);
		Log.e("String", (String) taskTextView.getText());
		String task = String.valueOf(taskTextView.getText());
		myDB.deleteTask(task);
		loadDataInListView();
	}
	public void loadDataInListView(){
		arrayList = myDB.getAllData();
		myAdapter = new MyAdapter(this,arrayList);
		lstTask.setAdapter(myAdapter);
		myAdapter.notifyDataSetChanged();
	}
}
