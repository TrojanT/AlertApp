package com.e.alertapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, TimePickerDialog.OnTimeSetListener {

    EditText textAlert;
    TextView datePick,timePick;
    Button datebtn,timebtn,lastbtn;
    Calendar startTime;
	DatabaseHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startTime = Calendar.getInstance();
		myDB = new DatabaseHelper(this);

        textAlert = findViewById(R.id.textAlert);
        datePick = findViewById(R.id.datePick);
        timePick = findViewById(R.id.timePick);
        datebtn = findViewById(R.id.datebtn);
        timebtn = findViewById(R.id.timebtn);
        findViewById(R.id.lastbtn).setOnClickListener(this);

        datebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                handleDateButton();
            }
        });

        timebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleTimeButton();
            }
        });

    }



    private void handleTimeButton() {
        Calendar calendar=Calendar.getInstance();
        int hour=calendar.get(Calendar.HOUR_OF_DAY);
        int minute=calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog=new TimePickerDialog(this,(TimePickerDialog.OnTimeSetListener) this,hour,minute, DateFormat.is24HourFormat(this));
        timePickerDialog.show();


    }

    private void handleDateButton() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int date = calendar.get(Calendar.DATE);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int date) {


                startTime.set(Calendar.MONTH,month);
                startTime.set(Calendar.YEAR,year);
                startTime.set(Calendar.DATE,date);

                String dateString = date+"-"+(month+1)+"-"+year;
                datePick.setText(dateString);
            }
        },year,month,date);

        datePickerDialog.show();

    }


	@Override
	public void onClick(View view) {

		Intent intent = new Intent(MainActivity.this, AlarmReceiver.class);
		intent.putExtra("todo", textAlert.getText().toString());

		PendingIntent alarmIntent = PendingIntent.getBroadcast(MainActivity.this, 0,
			intent, PendingIntent.FLAG_UPDATE_CURRENT);

		AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);

		switch (view.getId()) {
			case R.id.lastbtn:
				long alarmStartTime = startTime.getTimeInMillis();
				alarm.set(AlarmManager.RTC_WAKEUP, alarmStartTime, alarmIntent);
				Toast.makeText(this, "Done!", Toast.LENGTH_SHORT).show();
				String task = String.valueOf(textAlert.getText());
				String task2 =  String.valueOf(timePick.getText());
				String task3 = String.valueOf(datePick.getText());
				boolean addData = myDB.addData(task,task2,task3);
				break;


		}
		Intent intent1 =new Intent(MainActivity.this,Home.class );
		startActivity(intent1);
	}

    @Override
    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minuteofhour) {
                startTime.set(Calendar.HOUR_OF_DAY,hourOfDay);
                startTime.set(Calendar.MINUTE,minuteofhour);
                startTime.set(Calendar.SECOND,0);

        String timeString = hourOfDay+" : "+minuteofhour;
        timePick.setText(timeString);
    }
}
